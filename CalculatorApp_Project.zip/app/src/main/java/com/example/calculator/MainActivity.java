package com.example.calculator;
import android.app.*; import android.os.*; import android.widget.*; import android.view.*; import java.util.Locale;

public class MainActivity extends Activity {
 TextView d; double memory=0; double first=0; String op=""; boolean fresh=true;
 public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main); d=findViewById(R.id.display);
  int[] nums={R.id.b0,R.id.b1,R.id.b2,R.id.b3,R.id.b4,R.id.b5,R.id.b6,R.id.b7,R.id.b8,R.id.b9};
  for(int id:nums)findViewById(id).setOnClickListener(v->num(((Button)v).getText().toString()));
  int[] ops={R.id.add,R.id.sub,R.id.mul,R.id.div}; for(int id:ops)findViewById(id).setOnClickListener(v->operation(((Button)v).getText().toString()));
  findViewById(R.id.dot).setOnClickListener(v->dot()); findViewById(R.id.equal).setOnClickListener(v->equal());
  findViewById(R.id.clear).setOnClickListener(v->{d.setText("0");first=0;op="";fresh=true;});
  findViewById(R.id.back).setOnClickListener(v->{String s=d.getText().toString(); if(s.length()>1)d.setText(s.substring(0,s.length()-1));else d.setText("0");});
  findViewById(R.id.sign).setOnClickListener(v->{try{d.setText(fmt(-Double.parseDouble(d.getText().toString())));}catch(Exception e){}});
  findViewById(R.id.percent).setOnClickListener(v->{try{d.setText(fmt(Double.parseDouble(d.getText().toString())/100));}catch(Exception e){}});
  findViewById(R.id.mc).setOnClickListener(v->memory=0);
  findViewById(R.id.mr).setOnClickListener(v->{d.setText(fmt(memory));fresh=true;});
  findViewById(R.id.mplus).setOnClickListener(v->{memory+=val();});
  findViewById(R.id.mminus).setOnClickListener(v->{memory-=val();});
  findViewById(R.id.mrc).setOnClickListener(v->{d.setText(fmt(memory));fresh=true;});
 }
 double val(){try{return Double.parseDouble(d.getText().toString());}catch(Exception e){return 0;}}
 void num(String n){if(fresh||d.getText().toString().equals("0")){d.setText(n);fresh=false;}else d.append(n);}
 void dot(){if(fresh){d.setText("0.");fresh=false;}else if(!d.getText().toString().contains("."))d.append(".");}
 void operation(String o){first=val();op=o;fresh=true;}
 void equal(){double second=val(),r=second; if(op.equals("+"))r=first+second; else if(op.equals("−"))r=first-second; else if(op.equals("×"))r=first*second; else if(op.equals("÷"))r=second==0?0:first/second; d.setText(fmt(r));fresh=true;op="";}
 String fmt(double x){if(x==Math.rint(x))return String.format(Locale.US,"%.0f",x);return String.format(Locale.US,"%.10f",x).replaceAll("0+$","").replaceAll("\\.$","");}
}
